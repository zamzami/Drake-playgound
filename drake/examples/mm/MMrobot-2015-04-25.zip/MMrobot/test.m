N=5
Z= cell(1,N);
for k = 1:N
    Z{k} = k;
end
Z