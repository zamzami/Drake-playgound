% function sqend
%   Deallocate memory.
%

function sqend

endOpt = 999;
sqoptmex ( endOpt );